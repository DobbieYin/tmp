/**   
 * @Title: BatPathTest.java 
 * @Package com.tgyt.common.tools.bat.Test 
 * @Description: 
 * @author sunqiang sunqiangbingxue@sina.com
 * @date 2011-9-20 下午3:46:52 
 * @version V1.0   
 */

package com.tgyt.common.tools.bat.Test;

import org.junit.Test;
import com.tgyt.common.tools.bat.BatPath;

/**
 * @ClassName: BatPathTest
 * @Description: 测试在指定文件下的bat文件
 * @author sunqiang sunqiangbingxue@sina.com
 * @date 2011-9-20 下午3:46:52
 * 
 */
public class BatPathTest {
	/**
	 * @Title: batPathTest
	 * @Description: 测试在一个路径下，执行一个制定的bat文件
	 * @param
	 * @return void
	 * @throws
	 */
//	@Test
//	public void batPathTest() {
//		BatPath.batPath("D:\\Java\\workspace\\tgoa","delSVN.bat");
//	}
}
