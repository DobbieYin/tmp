package com.tgyt.permissions.biz;

import com.tgyt.framework.service.ServiceInterface;
import com.tgyt.permissions.model.RoleAuth;

public interface IRoleAuthService extends ServiceInterface<RoleAuth> {

}
