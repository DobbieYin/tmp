/**   
 * @Title: Condition.java 
 * @Package com.tgyt.framework.dao.hibernate 
 * @Description: 北京太谷雨田信息科技有限责任公司 版权所有 
 * @author zhangfeng  13940488705@163.com  
 * @date 2011-8-1 下午8:49:45 
 * @version V1.0   
 */

package com.tgyt.framework.dao.hibernate;

/**
 * @ClassName: Condition
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @author zhangfeng 13940488705@163.com
 * @date 2011-8-1 下午8:49:45
 * 
 */
public class Condition {
	protected String field;

	public String getField() {
		return field;
	}
}
