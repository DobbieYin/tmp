package com.tgyt.flowList.dao;

import org.springframework.stereotype.Repository;

import com.tgyt.flowList.model.TypeFlow;
import com.tgyt.framework.dao.hspring.BaseDAO;

@Repository(value="typeFlowDao")
public class TypeFlowDao extends BaseDAO<TypeFlow> {
  
}
